import React from 'react';
import { motion } from 'motion/react';
import { Star, MapPin, Phone, Clock, CheckCircle, Quote, ArrowRight, ShieldCheck, Award, ThumbsUp, ChevronRight } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white selection:bg-accent selection:text-accent-foreground">
      {/* Navigation */}
      <nav className="fixed w-full z-50 glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-display font-bold text-xl">F</span>
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-primary">
                Fatima's Driving School
              </span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#about" className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">The Experience</a>
              <a href="#reviews" className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">Success Stories</a>
              <a href="#contact" className="text-sm font-medium text-gray-600 hover:text-primary transition-colors">Contact</a>
              <a href="tel:+447828051142" className="inline-flex items-center justify-center px-6 py-2.5 text-sm font-semibold text-primary bg-accent rounded-full hover:bg-accent/90 transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5">
                Book a Lesson
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section - Split Layout */}
      <section className="relative pt-20 lg:pt-0 min-h-screen flex items-center">
        <div className="absolute inset-0 lg:hidden">
          <img 
            src="https://images.unsplash.com/photo-1580273916550-e323be2ae537?q=80&w=1000&auto=format&fit=crop" 
            alt="Driving background" 
            className="w-full h-full object-cover opacity-10"
            referrerPolicy="no-referrer"
          />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center min-h-[calc(100vh-5rem)]">
            
            {/* Left Content */}
            <div className="relative z-10 py-12 lg:py-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gray-50 border border-gray-200 mb-8 shadow-sm"
              >
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
                <span className="text-sm font-semibold text-primary">4.7/5 from 46 Google Reviews</span>
              </motion.div>

              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tighter text-primary mb-6 leading-[1.1]"
              >
                Master the road with <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-gray-500">confidence.</span>
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mt-4 text-lg sm:text-xl text-gray-600 max-w-lg mb-10 leading-relaxed"
              >
                Premium driving instruction in Bradford. Patient, supportive, and tailored to help you pass first time.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <a href="tel:+447828051142" className="inline-flex items-center justify-center px-8 py-4 text-base font-semibold text-primary bg-accent rounded-full hover:bg-accent/90 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5">
                  Start Your Journey
                  <ArrowRight className="ml-2 w-5 h-5" />
                </a>
                <a href="#reviews" className="inline-flex items-center justify-center px-8 py-4 text-base font-medium text-primary bg-white border-2 border-gray-100 rounded-full hover:border-gray-200 hover:bg-gray-50 transition-all">
                  Read Success Stories
                </a>
              </motion.div>
            </div>

            {/* Right Image - Desktop Only */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block relative h-[80vh] w-full"
            >
              <div className="absolute inset-0 rounded-[2.5rem] overflow-hidden shadow-2xl">
                <img 
                  src="https://i.postimg.cc/PxJWJT7D/Gemini-Generated-Image-fzb6z2fzb6z2fzb6.png" 
                  alt="Happy student driver" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                
                {/* Floating Badge */}
                <div className="absolute bottom-8 left-8 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-primary">Latest Success</p>
                    <p className="text-xs text-gray-600 font-medium">Rayhan passed today!</p>
                  </div>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* The Experience (Alternating Features) */}
      <section id="about" className="py-24 lg:py-32 bg-muted overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-sm font-bold tracking-widest text-accent uppercase mb-3">The Fatima Difference</h2>
            <h3 className="text-3xl md:text-5xl font-bold text-primary tracking-tight">Why students choose us</h3>
          </div>

          <div className="space-y-24 lg:space-y-32">
            {/* Feature 1 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative h-[400px] lg:h-[500px] rounded-[2rem] overflow-hidden shadow-xl"
              >
                <img 
                  src="https://i.postimg.cc/cHBmgFxV/why-choose.jpg" 
                  alt="Why students choose us" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="lg:pl-12"
              >
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-6 border border-gray-100">
                  <ShieldCheck className="w-7 h-7 text-accent" />
                </div>
                <h4 className="text-3xl font-bold text-primary mb-4">Patient & Supportive</h4>
                <p className="text-lg text-gray-600 leading-relaxed mb-6">
                  Learning to drive can be daunting. We take a calm, structured approach that helps you build confidence at your own pace. No pressure, just steady, measurable progress every single lesson.
                </p>
                <ul className="space-y-3">
                  {['Anxiety-free environment', 'Tailored to your learning speed', 'Constructive, positive feedback'].map((item, i) => (
                    <li key={i} className="flex items-center text-gray-700 font-medium">
                      <CheckCircle className="w-5 h-5 text-accent mr-3" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>

            {/* Feature 2 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-2 lg:order-1 lg:pr-12"
              >
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-6 border border-gray-100">
                  <Award className="w-7 h-7 text-accent" />
                </div>
                <h4 className="text-3xl font-bold text-primary mb-4">Effective Teaching</h4>
                <p className="text-lg text-gray-600 leading-relaxed mb-6">
                  We don't just teach you how to pass the test; we teach you how to be a safe driver for life. Our proven methods make complex maneuvers easy to understand and execute flawlessly.
                </p>
                <ul className="space-y-3">
                  {['Clear, step-by-step instructions', 'Modern, well-maintained vehicles', 'High first-time pass rate'].map((item, i) => (
                    <li key={i} className="flex items-center text-gray-700 font-medium">
                      <CheckCircle className="w-5 h-5 text-accent mr-3" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-1 lg:order-2 relative h-[400px] lg:h-[500px] rounded-[2rem] overflow-hidden shadow-xl"
              >
                <img 
                  src="https://i.postimg.cc/9X16spPj/Gemini-Generated-Image-kt0mmdkt0mmdkt0m.png" 
                  alt="Effective teaching driving instruction" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
          </div>

        </div>
      </section>

      {/* Reviews Section - Premium Cards */}
      <section id="reviews" className="py-24 lg:py-32 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <div className="max-w-2xl">
              <h2 className="text-sm font-bold tracking-widest text-accent uppercase mb-3">Wall of Love</h2>
              <h3 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">Success Stories</h3>
              <p className="text-lg text-white/70">
                Join 46+ happy students who have successfully earned their license with us.
              </p>
            </div>
            <div className="flex items-center gap-5 bg-white/5 backdrop-blur-sm px-6 py-4 rounded-2xl border border-white/10">
              <div className="text-5xl font-bold text-white">4.7</div>
              <div>
                <div className="flex gap-1 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-5 h-5 ${i < 4 || i === 4 ? 'fill-accent text-accent' : 'fill-white/20 text-white/20'}`} />
                  ))}
                </div>
                <div className="text-sm font-medium text-white/60">46 Google Reviews</div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: "Maymunah Hussain",
                time: "7 months ago",
                text: "She's an amazing driving instructor — patient, supportive, and always explains things clearly. Her calm approach has really helped me build confidence and enjoy learning to drive. Definitely would recommend her !!! Such a sweet and lovely driving instructor",
                image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop"
              },
              {
                name: "Mariam Tabraiz",
                time: "7 months ago",
                text: "Absolutely brilliant instructor! Super patient, made everything easy to understand, and always kept lessons relaxed and fun. I passed first time thanks to your support – couldn't have asked for a better instructor :)",
                image: "https://images.unsplash.com/photo-1531123897727-8f129e1bfa8ea?q=80&w=200&auto=format&fit=crop"
              },
              {
                name: "Sunaina Hussain",
                time: "6 months ago",
                text: "She's an Amazing driving instructor & patience also is very friendly. Her calm approach has really helped me build confidence & enjoy learning to drive, is very easy to get along with.",
                image: "https://images.unsplash.com/photo-1517524206127-48bbd363f3d7?q=80&w=200&auto=format&fit=crop"
              }
            ].map((review, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 relative hover:bg-white/10 transition-colors"
              >
                <Quote className="absolute top-8 right-8 w-10 h-10 text-white/10" />
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-white/90 mb-8 leading-relaxed relative z-10 text-lg">"{review.text}"</p>
                <div className="flex items-center gap-4">
                  <img 
                    src={review.image} 
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-white/20"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="font-bold text-white">{review.name}</div>
                    <div className="text-sm text-white/50">{review.time}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 flex flex-wrap justify-center gap-3">
            {['confidence (15)', 'patient (10)', 'test (4)', 'understand (3)', 'communication (2)', 'motivating (2)'].map((tag, i) => (
              <span key={i} className="px-5 py-2.5 bg-white/5 border border-white/10 text-white/80 rounded-full text-sm font-medium hover:bg-white/10 transition-colors cursor-default">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section - Premium Split */}
      <section id="contact" className="py-24 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary rounded-[3rem] overflow-hidden shadow-2xl">
            <div className="grid lg:grid-cols-2">
              
              {/* Contact Info */}
              <div className="p-10 lg:p-16 text-white flex flex-col justify-center">
                <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Ready to get behind the wheel?</h2>
                <p className="text-lg text-white/70 mb-12 max-w-md">
                  Contact us today to book your first lesson. We're here to help you become a safe, confident driver.
                </p>
                
                <div className="space-y-8">
                  <div className="flex items-center gap-6 group">
                    <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center shrink-0 group-hover:bg-accent transition-colors">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-white/50 mb-1 font-medium uppercase tracking-wider">Call or Text</div>
                      <a href="tel:+447828051142" className="text-2xl font-bold hover:text-accent transition-colors">
                        +44 7828 051142
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-white/50 mb-1 font-medium uppercase tracking-wider">Location</div>
                      <div className="text-xl font-medium">
                        11 Blythe Ave, Bradford<br />
                        <span className="text-white/70 text-lg">BD8 9EW, UK</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
                      <Clock className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-white/50 mb-1 font-medium uppercase tracking-wider">Hours</div>
                      <div className="text-xl font-medium">
                        Open daily until 5:00 PM
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Map Image */}
              <div className="relative h-[400px] lg:h-auto">
                <img 
                  src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=2074&auto=format&fit=crop" 
                  alt="Map of Bradford area" 
                  className="absolute inset-0 w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-primary/20 mix-blend-multiply"></div>
                
                {/* Floating Map Card */}
                <div className="absolute bottom-8 left-8 right-8 bg-white p-6 rounded-2xl shadow-2xl">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="font-bold text-xl text-primary mb-1">Fatima's Driving School</div>
                      <div className="text-gray-500 text-sm">11 Blythe Ave, Bradford</div>
                    </div>
                    <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <a 
                    href="https://maps.google.com/?q=11+Blythe+Ave,+Bradford+BD8+9EW,+United+Kingdom" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center w-full py-4 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors group"
                  >
                    Get Directions
                    <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 text-center border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-display font-bold text-sm">F</span>
            </div>
            <span className="font-display font-bold text-lg tracking-tight text-primary">
              Fatima's Driving School
            </span>
          </div>
          <p className="text-gray-500 font-medium">&copy; {new Date().getFullYear()} Fatima's Driving School. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
