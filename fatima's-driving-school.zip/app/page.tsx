"use client";

import Image from "next/image";
import { Star, MapPin, Phone, Clock, CheckCircle2, Quote, Menu, X, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "motion/react";

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-[#F5B301] selection:text-[#0a0f1c]">
      {/* Navigation */}
      <nav
        className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled ? "bg-[#0a0f1c]/95 backdrop-blur-md py-4 shadow-lg shadow-black/10 text-slate-50" : "bg-[#0a0f1c] py-6 text-slate-50"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-[#F5B301] flex items-center justify-center text-[#0a0f1c] font-bold text-xl">
              F
            </div>
            <span className="text-xl font-bold tracking-tight">Fatima's Driving School</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
            <a href="#about" className="hover:text-[#F5B301] transition-colors">About</a>
            <a href="#why-us" className="hover:text-[#F5B301] transition-colors">Why Us</a>
            <a href="#reviews" className="hover:text-[#F5B301] transition-colors">Reviews</a>
            <a href="#contact" className="hover:text-[#F5B301] transition-colors">Contact</a>
            <a href="#contact" className="bg-[#F5B301] text-[#0a0f1c] px-5 py-2.5 rounded-full font-semibold hover:bg-[#F5B301]/90 transition-colors">
              Book Lesson
            </a>
          </div>

          <button className="md:hidden text-slate-300" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#0a0f1c] text-slate-50 pt-24 px-6 md:hidden flex flex-col gap-6 text-lg">
          <a href="#about" onClick={() => setMobileMenuOpen(false)} className="border-b border-slate-800 pb-4">About</a>
          <a href="#why-us" onClick={() => setMobileMenuOpen(false)} className="border-b border-slate-800 pb-4">Why Us</a>
          <a href="#reviews" onClick={() => setMobileMenuOpen(false)} className="border-b border-slate-800 pb-4">Reviews</a>
          <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="border-b border-slate-800 pb-4">Contact</a>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-sm text-sm font-medium text-slate-600 mb-6">
                <Star className="w-4 h-4 text-[#F5B301] fill-[#F5B301]" />
                <span>4.7/5 from 46 Google Reviews</span>
              </div>
              <h1 className="text-5xl lg:text-7xl font-bold tracking-tight leading-[1.1] mb-6 text-slate-900">
                Master the road with <span className="text-[#F5B301]">confidence.</span>
              </h1>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-lg">
                Patient, supportive, and effective driving lessons in Bradford. We don't just teach you to pass; we teach you to be a safe driver for life.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#contact" className="inline-flex justify-center items-center gap-2 bg-[#F5B301] text-[#0a0f1c] px-8 py-4 rounded-full font-bold text-lg hover:bg-[#F5B301]/90 transition-all hover:scale-105 shadow-md">
                  Book Your First Lesson
                  <ArrowRight className="w-5 h-5" />
                </a>
                <a href="#reviews" className="inline-flex justify-center items-center gap-2 bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-50 transition-all shadow-sm">
                  Read Reviews
                </a>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative h-[300px] sm:h-[400px] lg:h-[600px] w-full rounded-3xl overflow-hidden shadow-2xl shadow-slate-200/50"
            >
              <Image 
                src="https://i.postimg.cc/PxJWJT7D/Gemini-Generated-Image-fzb6z2fzb6z2fzb6.png"
                alt="Happy student driver"
                fill
                className="object-cover"
                priority
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent opacity-60"></div>
              
              {/* Floating Success Badge */}
              <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md border border-slate-200 p-4 rounded-2xl shadow-xl">
                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full mt-1">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-500">Recent Success</p>
                    <p className="text-slate-900 font-semibold">"Congratulations rayhan passed his driving test today!"</p>
                    <p className="text-xs text-slate-500 mt-1">18 hours ago</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section id="why-us" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1 relative h-[300px] sm:h-[400px] lg:h-[500px] rounded-3xl overflow-hidden shadow-xl shadow-slate-200/50">
              <Image 
                src="https://i.postimg.cc/cHBmgFxV/why-choose.jpg"
                alt="Driving instruction"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl lg:text-5xl font-bold mb-6 text-slate-900">Why students <span className="text-[#F5B301]">choose us</span></h2>
              <p className="text-slate-600 text-lg mb-8">
                Learning to drive can be daunting, but with the right instructor, it becomes an enjoyable and rewarding journey.
              </p>
              
              <div className="space-y-6">
                {[
                  { title: "Patient & Supportive", desc: "A calm approach that helps build confidence, especially for nervous learners." },
                  { title: "Effective Teaching", desc: "Clear, easy-to-understand instructions tailored to your learning style." },
                  { title: "Fair Priced", desc: "High-quality instruction that offers excellent value for your investment." }
                ].map((feature, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center border border-slate-200">
                      <CheckCircle2 className="w-6 h-6 text-[#F5B301]" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 mb-1">{feature.title}</h3>
                      <p className="text-slate-600">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Effective Teaching */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl lg:text-5xl font-bold mb-6 text-slate-900">Effective <span className="text-[#F5B301]">Teaching</span></h2>
              <p className="text-slate-600 text-lg mb-6 leading-relaxed">
                We don't just teach you how to pass the test; we teach you how to be a safe driver for life. Our proven methods make complex maneuvers easy to understand and execute flawlessly.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3 text-slate-700 font-medium">
                  <div className="w-2 h-2 rounded-full bg-[#F5B301]"></div>
                  Clear, step-by-step instructions
                </li>
                <li className="flex items-center gap-3 text-slate-700 font-medium">
                  <div className="w-2 h-2 rounded-full bg-[#F5B301]"></div>
                  Modern, well-maintained vehicles
                </li>
                <li className="flex items-center gap-3 text-slate-700 font-medium">
                  <div className="w-2 h-2 rounded-full bg-[#F5B301]"></div>
                  High first-time pass rate
                </li>
              </ul>
            </div>
            <div className="relative h-[300px] sm:h-[400px] lg:h-[500px] rounded-3xl overflow-hidden shadow-xl shadow-slate-200/50">
              <Image 
                src="https://i.postimg.cc/9X16spPj/Gemini-Generated-Image-kt0mmdkt0mmdkt0m.png"
                alt="Hands on steering wheel"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Wall of Love (Reviews) */}
      <section id="reviews" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-4 text-slate-900">Wall of <span className="text-[#F5B301]">Love</span></h2>
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-[#F5B301] fill-[#F5B301]" />
                ))}
              </div>
              <span className="text-2xl font-bold text-slate-900">4.7</span>
            </div>
            <p className="text-slate-600">Based on 46 Google Reviews</p>
            
            <div className="flex flex-wrap justify-center gap-2 mt-8">
              {['confidence', 'patient', 'test', 'understand', 'communication', 'motivating'].map((tag) => (
                <span key={tag} className="px-4 py-1.5 rounded-full bg-slate-50 text-slate-700 text-sm border border-slate-200">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: "Maymunah Hussain",
                time: "7 months ago",
                text: "She’s an amazing driving instructor — patient, supportive, and always explains things clearly. Her calm approach has really helped me build confidence and enjoy learning to drive. Definitely would recommend her !!! Such a sweet and lovely driving instructor"
              },
              {
                name: "Mariam Tabraiz",
                time: "7 months ago",
                text: "Absolutely brilliant instructor! Super patient, made everything easy to understand, and always kept lessons relaxed and fun. I passed first time thanks to your support – couldn’t have asked for a better instructor :)"
              },
              {
                name: "Sunaina Hussain",
                time: "6 months ago",
                text: "She’s an Amazing driving instructor & patience also is very friendly. Her calm approach has really helped me build confidence & enjoy learning to drive, is very easy to get along with."
              }
            ].map((review, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-200 shadow-sm p-8 rounded-3xl relative">
                <Quote className="absolute top-6 right-6 w-8 h-8 text-slate-200" />
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-[#F5B301] fill-[#F5B301]" />
                  ))}
                </div>
                <p className="text-slate-700 mb-6 leading-relaxed">"{review.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center font-bold text-slate-700">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{review.name}</h4>
                    <p className="text-xs text-slate-500">{review.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Location */}
      <section id="contact" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="bg-white border border-slate-200 shadow-xl shadow-slate-200/40 rounded-[2.5rem] overflow-hidden">
            <div className="grid lg:grid-cols-2">
              <div className="p-12 lg:p-16">
                <h2 className="text-3xl lg:text-4xl font-bold mb-8 text-slate-900">Ready to get started?</h2>
                
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-[#F5B301]" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-1">Location</h3>
                      <p className="text-slate-600">11 Blythe Ave, Bradford BD8 9EW<br/>United Kingdom</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0">
                      <Clock className="w-5 h-5 text-[#F5B301]" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-1">Hours</h3>
                      <p className="text-slate-600">Open · Closes 5 pm</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0">
                      <Phone className="w-5 h-5 text-[#F5B301]" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-1">Phone</h3>
                      <p className="text-slate-600">+44 7828 051142</p>
                    </div>
                  </div>
                </div>

                <div className="mt-12">
                  <a href="tel:+447828051142" className="inline-flex justify-center items-center gap-2 bg-[#F5B301] text-[#0a0f1c] w-full px-8 py-4 rounded-full font-bold text-lg hover:bg-[#F5B301]/90 transition-all shadow-md">
                    Call Now to Book
                  </a>
                </div>
              </div>
              
              <div className="relative h-[350px] sm:h-[400px] lg:h-auto bg-slate-100 min-h-[350px] sm:min-h-[400px]">
                <iframe 
                  src="https://maps.google.com/maps?q=11%20Blythe%20Ave,%20Bradford%20BD8%209EW,%20United%20Kingdom&t=&z=14&ie=UTF8&iwloc=&output=embed" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={false} 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0 w-full h-full"
                ></iframe>
                <div className="absolute bottom-6 left-6 right-6 lg:right-auto flex items-center justify-center pointer-events-none">
                  <div className="bg-white/95 backdrop-blur-md border border-slate-200 p-4 rounded-2xl shadow-lg pointer-events-auto flex items-center gap-4 w-full max-w-sm">
                    <div className="bg-slate-100 p-2 rounded-full flex-shrink-0">
                      <MapPin className="w-5 h-5 text-[#F5B301]" />
                    </div>
                    <div className="text-left flex-1">
                      <h4 className="font-bold text-slate-900 text-sm">Fatima's Driving School</h4>
                      <p className="text-xs text-slate-600">11 Blythe Ave, Bradford</p>
                    </div>
                    <a href="https://maps.google.com/?q=11+Blythe+Ave,+Bradford+BD8+9EW" target="_blank" rel="noopener noreferrer" className="inline-block bg-slate-900 text-white px-4 py-2 rounded-full text-xs font-medium hover:bg-slate-800 transition-colors whitespace-nowrap">
                      Directions
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12 text-center text-slate-500">
        <div className="max-w-7xl mx-auto px-6">
          <p>© {new Date().getFullYear()} Fatima's Driving School. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
