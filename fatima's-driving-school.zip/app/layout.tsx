import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: "Fatima's Driving School | Bradford",
  description: "Premium driving lessons in Bradford. Patient, supportive, and effective teaching. High first-time pass rate.",
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
